const form = document.getElementById('chat-form');
const input = document.getElementById('user-input');
const chatBox = document.getElementById('chat-box');

form.addEventListener('submit', function(e) {
  e.preventDefault();
  const userMessage = input.value.trim();
  if (userMessage === '') return;

  appendMessage('user', userMessage);
  const botReply = getBotReply(userMessage);
  appendMessage('bot', botReply);
  input.value = '';
});

function appendMessage(sender, message) {
  const msgDiv = document.createElement('div');
  msgDiv.className = sender;
  msgDiv.textContent = message;
  chatBox.appendChild(msgDiv);
  chatBox.scrollTop = chatBox.scrollHeight;
}

function getBotReply(message) {
  message = message.toLowerCase();
  if (message.includes('hello')) return 'Hi there!';
  if (message.includes('how are you')) return 'I'm just a bot, but I'm good!';
  if (message.includes('help')) return 'How can I assist you today?';
  return 'Sorry, I didn't understand that.';
}
